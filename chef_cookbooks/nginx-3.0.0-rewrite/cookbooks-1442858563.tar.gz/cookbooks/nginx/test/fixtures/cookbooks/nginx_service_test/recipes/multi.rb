nginx_service 'multi1'

nginx_service 'multi2'
