# nginx_service_test

Installs nginx from distro packages
