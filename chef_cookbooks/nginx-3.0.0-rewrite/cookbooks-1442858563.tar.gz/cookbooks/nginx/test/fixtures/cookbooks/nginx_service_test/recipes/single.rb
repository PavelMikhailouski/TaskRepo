nginx_service 'single'
