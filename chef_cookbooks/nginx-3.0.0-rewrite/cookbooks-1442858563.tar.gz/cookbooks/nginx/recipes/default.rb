#
# Cookbook Name:: nginx
# Recipe:: default
#

# default recipe is intentionally left blank
